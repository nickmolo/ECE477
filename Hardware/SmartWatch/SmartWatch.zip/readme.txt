Dimensions: 1.45" x 1.6"

Area: 2.32"

Copies: 10